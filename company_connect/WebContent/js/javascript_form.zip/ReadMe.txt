JavaScript Form Validator script__

For documentation, visit the following links:
http://www.javascript-coder.com/html-form/javascript-form-validation.phtml

http://www.javascript-coder.com/html-form/form-validation.phtml


There are several sample forms and validation scripts in the examples sub folder

